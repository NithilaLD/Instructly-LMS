# AI Email Notification

Full Composer Command List

1. `composer install`  
   Installs dependencies from `composer.lock` (or resolves from `composer.json` if lock is missing).

2. `composer update`  
   Updates dependencies to newer allowed versions and rewrites `composer.lock`.

3. `composer require vendor/package`  
   Adds a package and installs it.

4. `composer remove vendor/package`  
   Removes a package and updates lock/autoload.

5. `composer dump-autoload -o`  
   Rebuilds optimized autoload files.

6. `composer validate`  
   Checks `composer.json` for errors.

7. `composer show`  
   Lists installed packages (or details for one package).

8. `composer outdated`  
   Shows packages with newer versions available.

9. `composer audit`  
   Checks for known security vulnerabilities.

10. `composer why vendor/package`  
	Shows why a package is installed.

11. `composer why-not vendor/package version`  
	Shows what blocks a specific version (also called `composer prohibits`).

12. `composer fund`  
	Shows funding/sponsorship links for dependencies.

13. `composer licenses`  
	Shows dependency licenses.

14. `composer check-platform-reqs`  
	Verifies PHP/extensions match package requirements.

15. `composer diagnose`  
	Runs health checks on Composer setup.

16. `composer clear-cache`  
	Clears Composer cache.

17. `composer config --list`  
	Shows Composer configuration values.

18. `composer run-script script-name`  
	Runs scripts from the `scripts` section in `composer.json`.

19. `composer create-project vendor/project folder`  
	Creates a new project from a package template.

20. `composer status`  
	Shows local changes in `vendor` packages (useful if you edited vendor code).

21. `composer self-update`  
	Updates Composer itself (works for global Composer PHAR installs)
